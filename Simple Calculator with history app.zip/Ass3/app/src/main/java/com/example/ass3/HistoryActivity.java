package com.example.ass3;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.os.Bundle;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        TextView tvHistory = findViewById(R.id.tvHistory1);

        // Retrieve the history text from the Intent
        String historyText = getIntent().getStringExtra("historyText");

        // Set the history text in the TextView
        tvHistory.setText(historyText);
    }
}