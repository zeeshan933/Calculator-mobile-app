package com.example.ass3;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        progressBar = findViewById(R.id.progressBar);

        // Set the duration for the animation in milliseconds
        int animationDuration = 5000;

        // Set up the ObjectAnimator with left-to-right translation
        ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", 0, 100);
        animation.setDuration(animationDuration);
        animation.setInterpolator(new DecelerateInterpolator());

        // Set up an AnimatorListener to navigate to the next page when the animation is complete
        animation.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
                // Animation started
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                // Animation ended, navigate to the next page
                startActivity(new Intent(WelcomeActivity.this, Calculator.class));
                finish(); // Optional: Finish the current activity if needed
            }

            @Override
            public void onAnimationCancel(Animator animator) {
                // Animation canceled
            }

            @Override
            public void onAnimationRepeat(Animator animator) {
                // Animation repeated
            }
        });

        // Start the animation
        animation.start();
    }
}


