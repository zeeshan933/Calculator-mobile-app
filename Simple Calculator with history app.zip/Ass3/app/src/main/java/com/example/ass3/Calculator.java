package com.example.ass3;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Comparator;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.ArrayList;
import java.util.LinkedList;


public class Calculator extends AppCompatActivity {

    private EditText etFirst, etSecond;
    private Button btnSum, btnSub, btnMul, btnDiv;
    private TextView tvResult;
    private LinkedList<String> calculationHistory;


    private static final String PREFS_NAME = "CalculationHistoryPrefs";
    private static final String HISTORY_KEY = "calculationHistory";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        etFirst = findViewById(R.id.etFirst);
        etSecond = findViewById(R.id.etSecond);
        btnSum = findViewById(R.id.btnSum);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        tvResult = findViewById(R.id.tvResult);
        //tvHistory = findViewById(R.id.tvHistory);

        calculationHistory = new LinkedList<>(); // Initialize the set
        calculationHistory.addAll(loadCalculationHistory()); // Load history from SharedPreferences
        String formattedHistoryText = getFormattedHistoryText();


        btnSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sum= "1";
                String sub = "0", mul="0", div="0";
                calculate(sum,sub,mul,div);
            }
        });
        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String  sub= "1";
                String sum = "0", mul="0", div="0";
                calculate(sum,sub,mul,div);
            }
        });
        btnMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mul= "1";
                String sub = "0", sum="0", div="0";
                calculate(sum,sub,mul,div);
            }
        });
        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String div= "1";
                String sub = "0", mul="0", sum="0";
                calculate(sum,sub,mul,div);
            }
        });
        Button btnGoToHistory = findViewById(R.id.btnGoToHistory);

        // Set a click listener for the button
        btnGoToHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Call the function to go to the HistoryActivity
                goToHistoryActivity();
            }
        });
    }
    public String double_to_int(double answer) {
        if (answer % 1 == 0) {
            // It's a whole number, convert to int and return as String
            return String.valueOf((int) answer);
        }
        // It has a decimal part, return as String
        return String.valueOf(answer);
    }
    private void calculate(String sum , String sub, String mul, String div) {
        try {
            double value1 = Double.parseDouble(etFirst.getText().toString());
            double value2 = Double.parseDouble(etSecond.getText().toString());
            double result = 0.0;
            String strAns , number1 , number2;
            number1 = double_to_int(value1);
            number2 = double_to_int(value2);
            if ("1".equals(sum)){
                result = value1 + value2;
                strAns = double_to_int(result);
                String Message = "Addition of: " + number1 + " + " + number2 + " = "+  strAns;
                tvResult.setText(Message);
            }else if ("1".equals(sub)) {
                result = value1 - value2;
                strAns = double_to_int(result);
                String Message = "Subtraction of: " + number1 + " - " + number2 + " = "+ strAns;;
                tvResult.setText(Message);
            }else if ("1".equals(mul)) {
                result = value1 * value2;
                strAns = double_to_int(result);
                String Message = "Multiplication of: " + number1 + " * " + number2 + " = "+strAns;;
                tvResult.setText(Message);
            }else if ("1".equals(div)) {
                result = value1 / value2;
                strAns = double_to_int(result);
                String Message = "Division of: " + number1 + " / " + number2 + " = "+strAns;;
                tvResult.setText(Message);
            }else {
                tvResult.setText("Invalid input");
            }
            // Store the calculation in history
            storeInHistory(value1, value2, result,sum,sub,mul,div);
        } catch (NumberFormatException e) {
            tvResult.setText("Invalid input");
        }
    }


  private void storeInHistory(double value1, double value2, double result, String sum , String sub, String mul, String div) {
      long timestamp = System.currentTimeMillis(); // Get current time in milliseconds
      String strResult, number1,number2;
      strResult = double_to_int(result);
      number1 = double_to_int(value1);
      number2 = double_to_int(value2);
      String historyEntry = "0";
      if ("1".equals(sum)){
           historyEntry = number1 + " + " + number2 + " = " + strResult ;
      } else if ("1".equals(sub)) {
          historyEntry = number1 + " - " + number2 + " = " + strResult ;
      }else if ("1".equals(mul)) {
          historyEntry = number1 + " * " + number2 + " = " + strResult ;
      }else if ("1".equals(div)) {
          historyEntry = number1 + " / " + number2 + " = " + strResult ;
      }
      String entryWithTimestamp = historyEntry +  " (" + timestamp + ")";
      calculationHistory.addFirst(entryWithTimestamp);

      // Save the updated calculation history
      saveCalculationHistory(calculationHistory);
      String formattedHistoryText = getFormattedHistoryText();
  }

   private ArrayList<String> loadCalculationHistory() {
       SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
       Set<String> historySet = prefs.getStringSet(HISTORY_KEY, new HashSet<>());

       // Convert the Set to an ArrayList
       ArrayList<String> historyList = new ArrayList<>(historySet);

       // Sort the ArrayList based on timestamps
       Collections.sort(historyList, new Comparator<String>() {
           @Override
           public int compare(String entry1, String entry2) {
               long timestamp1 = extractTimestamp(entry1);
               long timestamp2 = extractTimestamp(entry2);
               return Long.compare(timestamp2, timestamp1); // Sort in descending order
           }
       });

       return historyList;
   }

    private long extractTimestamp(String entry) {
        int openParenthesisIndex = entry.lastIndexOf("(");
        int closeParenthesisIndex = entry.lastIndexOf(")");

        if (openParenthesisIndex != -1 && closeParenthesisIndex != -1 && openParenthesisIndex < closeParenthesisIndex) {
            try {
                return Long.parseLong(entry.substring(openParenthesisIndex + 1, closeParenthesisIndex));
            } catch (NumberFormatException e) {
                // Handle the case where parsing the timestamp fails
                e.printStackTrace();
            }
        }

        // Default timestamp in case of errors
        return 0;
    }

    private void saveCalculationHistory(Collection<String> historyCollection) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putStringSet(HISTORY_KEY, new HashSet<>(historyCollection));
        editor.apply();
    }

    private String getFormattedHistoryText() {
        StringBuilder historyText = new StringBuilder();

        for (String entry : calculationHistory) {
            // Split the entry to remove the timestamp
            String[] parts = entry.split("\\s*\\(\\d+\\)\\s*");

            // Append the display text without the timestamp
            historyText.append(parts[0]).append("\n");
        }
        return historyText.toString();
    }
    private void goToHistoryActivity() {
        // Get the formatted history text
        String formattedHistoryText = getFormattedHistoryText();

        // Start the HistoryActivity and pass the history text as an extra
        Intent intent = new Intent(Calculator.this, HistoryActivity.class);
        intent.putExtra("historyText", formattedHistoryText);
        startActivity(intent);
    }



}
